# iFAST Media Sentinel prototype

A responsive, white-theme personal media monitoring command centre for third-party coverage of iFAST Corporation from **1 January 2026 to 15 June 2026**.

## Latest changes in this build
- Expanded the hidden **Monitored Radar Channels** source universe to include the latest radar list: TS2 Tech, TMAstreet, Global Banking & Finance Review, MEXC, Minichart Singapore, Reuters, MarketScreener, Sporeshare Blog, KLSE Screener, eNanyang and ShareInvestor Classic.
- Deduplicated overlapping radar entries already present in the app, while keeping the more specific preferred URLs where useful: `mexc.com/en-GB`, `minichart.com.sg`, `klsescreener.com/v2`, `ts2.tech/en` and `classic.shareinvestor.com/sg`.
- The default radar now contains **37 deduplicated target portals** across mainstream media, online news, blogs and forums.
- Added source inference for the new domains so RSS/API imports receive clean source names and source-type tags automatically.
- Added an explicit **Google News expanded radar portals** query route, so the Google News/RSS method searches the new radar sources in addition to the normal source-domain batches and body-scan routes.
- Strengthened portal deduplication by URL target and portal name so older custom/local entries with the same source name do not duplicate the default radar list.
- Bumped the PWA cache version so browsers are encouraged to fetch the refreshed build.
- Kept real-link-only mode. No simulated rows or `#` placeholder links are created.

## Earlier retained features
- Selectable monitoring window: **1 January 2026 - 15 June 2026**.
- Locked basic keyword set: `iFAST`, `IFAST corp`, `ifast corporation`, `奕丰`, and `AIY`.
- Optional keyword bar remains available only for future search expansion, not dashboard filtering.
- Source Type filter and visible article tags:
  - Mainstream media
  - Forum
  - Blog
  - Online news
- Hidden/editable **Monitored Radar Channels** for target portals and Google Alerts RSS feeds.
- The default radar now contains 37 deduplicated target portals, and the editable portal bar remains available for new commonly used media sites without changing the dashboard code.

## Why January-March was empty before
The date picker had been expanded, but the verified seed list mostly started from mid-April 2026. That meant January-March was a valid selectable period but had few or no local rows unless RSS/API sync returned live links. This build adds a January-March real-link cohort and changes the sync fallback from a broad Google search to date-scoped Google Search News routes.

## Included January-March seed coverage
This build includes verified real-link rows dated from January through March 2026, so the expanded timeline is no longer visually empty before April. Examples include the January Financial Alliance acquisition coverage, February FY2025 results / COO / FSM Global coverage, and March notes / RHB initiation coverage.


## Expanded radar sources added/confirmed
The hidden source universe now includes the following newly supplied or newly normalised portals:

| Source | Classification | Radar URL behaviour |
| --- | --- | --- |
| TS2 Tech | Online news | Added as a new locked default portal. |
| TMAstreet | Online news | Already present and retained. |
| Global Banking & Finance Review | Online news | Already present and retained. |
| MEXC | Online news | Updated to the requested English regional route. |
| Minichart Singapore | Online news | Updated from the broader Minichart domain to the Singapore domain. |
| Reuters | Mainstream media | Already present and retained. |
| MarketScreener | Online news | Already present and retained. |
| Sporeshare Blog | Blog | Added as a new locked default portal. |
| KLSE Screener | Online news | Updated to the requested v2 route. |
| eNanyang | Mainstream media | Already present and retained. |
| ShareInvestor Classic | Online news | Added as a new locked default portal. |

These portals remain hidden from the main dashboard, but appear in **Monitored Radar Channels** for audit and are sent to the production search endpoint through `preferredSources`.

## Real-link mode
The front end validates imported rows before display:

- URL must start with `http://` or `https://`.
- Google News aggregator URLs are not stored as article rows unless resolved to the publisher URL.
- Internal iFAST-owned domains are excluded.
- Rows containing internal research, asset allocation, press release or advisory wording are excluded.
- Duplicates are removed by normalised URL.

## Google Search News / RSS method
When no production API is connected, the browser first tries generated Google News RSS URLs like:

```text
https://news.google.com/rss/search?q=<encoded query with after:YYYY-MM-DD before:YYYY-MM-DD>&hl=en-SG&gl=SG&ceid=SG:en
```

If browser CORS blocks the RSS fetch, the app opens a real Google Search News URL like:

```text
https://www.google.com/search?tbm=nws&tbs=cdr:1,cd_min:1/1/2026,cd_max:6/15/2026&q=<encoded query>
```

This is a safe browser-only fallback. RSS rows are imported only when the app receives direct publisher links; Google News aggregator links are treated as review routes and not added as monitoring rows. For reliable production imports, connect a server-side search/RSS endpoint that resolves Google News links to canonical publisher URLs.

## Production sync payload
Connect a server-side endpoint by defining `window.SENTINEL_SEARCH_API` before the app script loads. The app posts:

```json
{
  "from": "2026-01-01",
  "to": "2026-06-15",
  "searchMode": "google_news_rss_plus_grounded_search",
  "keywords": ["iFAST", "IFAST corp", "ifast corporation", "奕丰", "AIY"],
  "coreKeywords": ["iFAST", "IFAST corp", "ifast corporation", "奕丰", "AIY"],
  "googleNewsQueries": ["..."],
  "googleNewsUrls": ["..."],
  "googleNewsRssFeeds": [{"name": "...", "url": "...", "allowBodyOnly": true, "query": "..."}],
  "googleNewsRssUrls": ["..."],
  "bodySearchRoutes": ["..."],
  "matchPolicy": "headline_or_body_keyword_match",
  "requireBodyScan": true,
  "headlineOnly": false,
  "requireRealUrl": true,
  "excludeInternal": true,
  "excludeOwnedChannels": true,
  "sourceTypes": ["Mainstream media", "Forum", "Blog", "Online news"],
  "preferredSources": [{"name": "Reuters", "url": "https://www.reuters.com/", "sourceType": "Mainstream media"}],
  "preferredSourceDomains": ["reuters.com", "marketscreener.com", "tmastreet.com", "ts2.tech"]
}
```

The production search layer should:

1. Run the Google Search News/date-range queries and/or Google News RSS search URLs.
2. Fetch the destination article pages server-side.
3. Scan headline, article body, snippets, captions and forum messages for the core keywords.
4. Discard internal iFAST-owned pages, corporate press releases, internally quoted advisory/research content and duplicate URLs.
5. Return clean JSON rows with title, source, URL, date, summary, sentiment, entity level and source type.

## Google Alerts RSS
The browser-only prototype tries a public RSS proxy when no company proxy is configured. For production, define `window.SENTINEL_RSS_PROXY` or fetch the Google Alerts RSS feeds server-side, then return clean JSON/XML to the app.

## Local testing

```bash
python3 -m http.server 8080
```

Then open `http://localhost:8080`.
